console.log("Developed By - Ayushman Medcalia, follow on Insta- @coder_320");

document.getElementById('github').addEventListener('click', function() {
    window.open('https://github.com/ayushman542', '_blank');
});

document.getElementById('youtube').addEventListener('click', function() {
    window.open('https://www.youtube.com/@javascript890', '_blank');
});

document.getElementById('demo').addEventListener('click', function() {
    window.open('', '_blank');
});


document.getElementById('tele').addEventListener('click', function() {
    window.open('https://t.me/helpinghandlpu', '_blank');
});

document.getElementById('insta').addEventListener('click', function() {
    window.open('https://www.instagram.com/coder_320/', '_blank');
});
console.log("Developer By Ayushman Medcalia , Follow me on telegram https://t.me/helpinghandlpu , follow me on Github https://github.com/ayushman542 , Follow me on linkedin https://www.linkedin.com/in/ayushman-medcalia-4a0908252/ ");
